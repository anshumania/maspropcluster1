#!/bin/bash
#
# Author: Michal "Karm" Babacek
#
# Script version: 1
#

java -cp "Hidato/lib/GameLib.jar:Hidato/HidatoApplication.jar" biz.karms.hidato.app.controller.impl.HidatoApplicationController
