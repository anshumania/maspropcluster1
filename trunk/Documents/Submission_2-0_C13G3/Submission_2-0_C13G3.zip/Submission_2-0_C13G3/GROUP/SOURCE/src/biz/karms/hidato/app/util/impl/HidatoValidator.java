package biz.karms.hidato.app.util.impl;

import com.masprop.cluster1.shared.controller.GameValidator;
import com.masprop.cluster1.shared.model.Game;

/**
 *
 * @author
 */
public class HidatoValidator implements GameValidator {

    public HidatoValidator() {
    }



    /**
     * 
     * @param game
     * @return
     */
    public boolean validateGame(Game game) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}