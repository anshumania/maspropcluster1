/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package biz.karms.hidato.app.controller.impl;

import com.masprop.cluster1.shared.controller.StatisticsManager;
import com.masprop.cluster1.shared.model.Game;
import java.util.List;

/**
 *
 * @author matusko
 */
class HidatoStatisticsManager implements StatisticsManager {

    public HidatoStatisticsManager() {
    }

    public void getScoreFor(Game game) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setScoreFor(Game game) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public List<Game> loadGame() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void saveGame(Game game) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public List<String> getStatistics() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
