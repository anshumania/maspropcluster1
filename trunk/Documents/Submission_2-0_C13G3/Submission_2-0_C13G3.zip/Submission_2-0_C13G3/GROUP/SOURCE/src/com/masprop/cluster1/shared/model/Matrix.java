package com.masprop.cluster1.shared.model;

/**
 * Class defines a game grid which contains <tt>cell</tt>s.
 *
 * @see Cell
 * @author Andrea Gritti
 */
public interface Matrix {
}