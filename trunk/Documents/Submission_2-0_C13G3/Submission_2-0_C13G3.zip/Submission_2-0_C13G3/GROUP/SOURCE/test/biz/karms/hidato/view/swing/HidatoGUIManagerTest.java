package biz.karms.hidato.view.swing;

import com.masprop.cluster1.shared.model.Constraint;
import com.masprop.cluster1.shared.model.Game;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michal "Karm" Babacek
 */
public class HidatoGUIManagerTest {

    public HidatoGUIManagerTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getNewGame method, of class HidatoGUIManager.
     */
    @Test
    public void testGetNewGame() {
        System.out.println("getNewGame");
        fail("The test case is a prototype.");
    }

    /**
     * Test of initializeCells method, of class HidatoGUIManager.
     */
    @Test
    public void testInitializeCells() {
        System.out.println("initializeCells");
        fail("The test case is a prototype.");
    }

}