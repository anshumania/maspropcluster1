package com.masprop.cluster1.shared.model;

/**
 * An interface to extend and enumarate different
 * variants of a <tt>Game</tt>.
 * 
 * @see Game
 * @autho Matteo de Martino
 * @version 1.0
 * @since 1.0
 * 
 */
public interface GameVariant {
}

